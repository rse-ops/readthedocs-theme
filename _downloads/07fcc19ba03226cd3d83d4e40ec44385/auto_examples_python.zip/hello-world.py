
"""
This is the title
=================

The title is required for the example to show up.
Hello world!

"""


print(__doc__)

usage = "Usage: python hello-world.py"

def print_hello_world():
    print("Hello World!")

if __name__ == '__main__':
    print_hello_world()
